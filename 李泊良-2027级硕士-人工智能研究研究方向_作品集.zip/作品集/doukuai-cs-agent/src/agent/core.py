"""Agent 核心循环：感知 → 检索 → 推理 → 行动 → 观察 → 循环。
短视频平台 AI 客服的主控逻辑，串联意图识别、知识检索、LLM 推理、工具调用。
"""

import json
from typing import AsyncIterator
import anthropic
from src.utils import settings, logger
from src.db import Conversation, Message, SessionStatus
from .prompts import SYSTEM_PROMPT
from .memory import Memory
from .intent import IntentClassifier
from .tools import TOOL_REGISTRY, get_tool_defs


class CustomerServiceAgent:
    """短视频平台 AI 客服智能体。"""

    def __init__(self, anthropic_client, retriever, db_session_factory):
        self.client = anthropic_client
        self.retriever = retriever  # RAG 检索器
        self.db_factory = db_session_factory
        self.intent_classifier = IntentClassifier(anthropic_client, settings.anthropic_model)
        self.model = settings.anthropic_model
        self.max_iterations = settings.max_agent_iterations

    async def run(
        self,
        user_input: str,
        user_id: str,
        user_type: str = "normal",
        user_name: str = "",
        conversation_id: str = "",
    ) -> AsyncIterator[dict]:
        """
        执行一次 Agent 推理循环。yield 流式事件：
        {"type": "text", "content": "..."}          — 文本块
        {"type": "tool_call", "name": "...", "input": {...}}  — 工具调用
        {"type": "done", "summary": "...", "intent": "...", "confidence": 0.0}  — 完成
        """
        # 1. 意图识别
        intent = await self.intent_classifier.classify(user_input)
        logger.info("意图识别", user_id=user_id, intent=intent["primary"], confidence=intent["confidence"])

        # 2. 加载或创建会话
        memory = Memory()
        conv = None
        async with self.db_factory() as db_session:
            from src.db.repository import ConversationRepo
            conv_repo = ConversationRepo(db_session)

            if conversation_id:
                conv = await conv_repo.get(conversation_id)
            if not conv:
                conv = await conv_repo.get_active_by_user(user_id)

            if conv:
                # 加载历史消息到记忆
                history = await conv_repo.get_messages(conversation_id=conv.id, limit=30)
                for msg in history:
                    memory.add(msg.sender_type, msg.content)
                conversation_id = conv.id
            else:
                conv = Conversation(
                    user_id=user_id, user_type=user_type, user_name=user_name,
                    status=SessionStatus.AI_PROCESSING,
                )
                conv = await conv_repo.create(conv)
                conversation_id = conv.id

            # 保存用户消息
            user_msg = Message(
                conversation_id=conversation_id, sender_type="user",
                content=user_input, msg_type="text",
            )
            await conv_repo.add_message(user_msg)

        memory.add("user", user_input)

        # 3. 检索知识库
        kb_docs = await self.retriever.retrieve(user_input, intent["primary"])
        knowledge_context = self.retriever.format_context(kb_docs) if kb_docs else "暂无匹配知识，请根据通用客服经验回复并引导转人工。"

        # 4. 构建系统提示词
        system_prompt = SYSTEM_PROMPT.format(
            user_type=user_type,
            user_name=user_name or "未知用户",
            knowledge_context=knowledge_context,
            memory_context=memory.get_context(),
        )

        # 5. LLM 推理循环
        messages = [{"role": "user", "content": user_input}]
        iteration = 0
        full_response = ""
        tool_calls_made = []

        try:
            while iteration < self.max_iterations:
                iteration += 1
                response = self.client.messages.create(
                    model=self.model,
                    max_tokens=2048,
                    system=system_prompt,
                    messages=messages,
                    tools=get_tool_defs(),
                )

                # 处理文本响应 — 流式输出
                for block in response.content:
                    if block.type == "text":
                        text = block.text
                        full_response += text
                        yield {"type": "text", "content": text}

                    # 处理工具调用
                    elif block.type == "tool_use":
                        tool_name = block.name
                        tool_input = block.input
                        logger.info("Agent 调用工具", tool=tool_name, input=str(tool_input)[:100])
                        yield {"type": "tool_call", "name": tool_name, "input": tool_input}

                        # 执行工具
                        result = await self._execute_tool(
                            tool_name, tool_input, user_id, conversation_id, intent, memory
                        )
                        tool_calls_made.append({"tool": tool_name, "result": str(result)[:200]})

                        # 将工具调用和结果追加到对话
                        messages.append({"role": "assistant", "content": [block]})
                        messages.append({
                            "role": "user",
                            "content": [{"type": "tool_result", "tool_use_id": block.id, "content": str(result)}],
                        })

                        # 如果是转人工，直接结束
                        if tool_name == "transfer_to_human":
                            yield {"type": "done", "summary": full_response, "intent": intent["primary"],
                                   "confidence": intent["confidence"], "action": "transfer_to_human"}
                            return

                # 如果没有工具调用，推理结束
                if all(block.type == "text" for block in response.content):
                    break

        except Exception as e:
            logger.error("Agent 运行异常", error=str(e))
            yield {"type": "text", "content": "抱歉，我遇到了一些技术问题。正在为您转接人工客服..."}
            yield {"type": "done", "summary": full_response, "intent": intent["primary"],
                   "confidence": 0.0, "action": "error"}

        # 6. 保存 AI 响应和会话状态
        async with self.db_factory() as db_session:
            from src.db.repository import ConversationRepo
            conv_repo = ConversationRepo(db_session)
            ai_msg = Message(
                conversation_id=conversation_id, sender_type="ai", content=full_response,
                msg_type="text", intent=intent["primary"], confidence=intent["confidence"],
            )
            await conv_repo.add_message(ai_msg)

            # 更新会话意图
            conv = await conv_repo.get(conversation_id)
            if conv and not conv.intent_category:
                await conv_repo.set_summary(conversation_id, full_response[:200])

        yield {"type": "done", "summary": full_response, "intent": intent["primary"],
               "confidence": intent["confidence"], "action": "resolved"}

    async def _execute_tool(self, name: str, params: dict, user_id: str, conv_id: str,
                            intent: dict, memory: Memory) -> str:
        """执行工具调用，将工具注册表中的占位实现替换为真实逻辑。"""
        if name == "search_knowledge_base":
            query = params.get("query", "")
            category = params.get("category", intent.get("primary", "other"))
            docs = await self.retriever.retrieve(query, category)
            if docs:
                return "\n\n---\n\n".join(f"[知识 {i+1}]\n{d}" for i, d in enumerate(docs))
            return "未找到相关知识，建议引导用户转人工。"

        elif name == "check_user_info":
            # 生产环境对接平台用户服务 API
            return json.dumps({
                "user_id": user_id,
                "status": "mock — 生产环境对接平台 API",
            }, ensure_ascii=False)

        elif name == "create_ticket":
            async with self.db_factory() as db_session:
                from src.db.repository import TicketRepo
                from src.db.models import Ticket
                ticket_repo = TicketRepo(db_session)
                ticket = Ticket(
                    conversation_id=conv_id,
                    title=params.get("title", "用户咨询"),
                    category=params.get("category", "other"),
                    priority=params.get("priority", "medium"),
                )
                await ticket_repo.create(ticket)
                return f"工单已创建：{ticket.id}，将有专人跟进处理。"

        elif name == "transfer_to_human":
            reason = params.get("reason", "用户请求")
            summary = params.get("summary", "")
            async with self.db_factory() as db_session:
                from src.db.repository import ConversationRepo
                conv_repo = ConversationRepo(db_session)
                await conv_repo.update_status(conv_id, SessionStatus.HUMAN_PROCESSING)
                await conv_repo.set_summary(conv_id, summary)
            logger.info("转人工", conv_id=conv_id, reason=reason)
            return f"已转接人工客服。原因：{reason}"

        return f"工具 {name} 执行成功。"
