"""意图识别：基于 LLM 的意图分类器，带关键词兜底。"""

import json
import re
from src.utils import logger

# 关键词 → 意图映射表（LLM 不可用时的快速兜底）
KEYWORD_INTENT_MAP = {
    # 闲聊寒暄
    "^(你好|hi|hello|嗨|哈喽|在吗|在不在|早上好|下午好|晚上好)": ("chitchat", "问候"),
    "^(谢谢|感谢|多谢|辛苦了|太棒了|很好|不错|有用|厉害)": ("chitchat", "感谢/夸奖"),
    "^(再见|拜拜|bye|下次|回头|走了)": ("chitchat", "告别"),
    # 视频创作
    "拍摄|怎么拍|运镜|构图|打光|布光|手机拍|相机拍|画质|清晰度": ("video_create", "拍摄技巧"),
    "剪辑|剪映|PR|Premiere|剪视频|卡点|转场|字幕|调色|滤镜": ("video_create", "剪辑教程"),
    "配乐|BGM|背景音乐|音效|音乐版权|热门音乐|卡点音乐": ("video_create", "音乐配乐"),
    "文案|标题|怎么写|脚本|剧本|选题|内容策划|创意": ("video_create", "文案写作"),
    "封面|缩略图|点击率|标题党": ("video_create", "封面设计"),
    # 账号问题
    "登录|登不上|密码|验证码|封号|封禁|账号冻结|找回账号|实名|认证失败": ("account", "账号问题"),
    # 内容运营
    "发布|上传|发不了|审核|申诉|限流|播放量|0播放|没流量|原创|版权|热门|推荐|算法": ("content", "内容运营"),
    # 变现
    "提现|收益|到账|钱包|打赏|佣金|带货|创作者计划|分成|结算|赚钱": ("monetize", "变现相关"),
    # 社交互动
    "评论|私信|举报|拉黑|粉丝|关注|涨粉": ("social", "互动社交"),
    # 平台功能
    "设置|隐私|青少年|版本|怎么用|功能介绍": ("platform", "平台功能"),
}


class IntentClassifier:
    """意图分类器：先走 LLM 精准分类，失败时降级为关键词匹配。"""

    def __init__(self, anthropic_client, model: str):
        self.client = anthropic_client
        self.model = model

    async def classify(self, user_message: str) -> dict:
        """返回 {"primary": str, "secondary": str, "confidence": float}"""
        try:
            return await self._llm_classify(user_message)
        except Exception as e:
            logger.warning("LLM 意图分类失败，降级关键词匹配", error=str(e))
            return self._keyword_fallback(user_message)

    async def _llm_classify(self, user_message: str) -> dict:
        from .prompts import INTENT_PROMPT
        prompt = INTENT_PROMPT.format(user_message=user_message)

        response = self.client.messages.create(
            model=self.model,
            max_tokens=256,
            messages=[{"role": "user", "content": prompt}],
        )
        text = response.content[0].text
        json_match = re.search(r'\{[\s\S]*\}', text)
        if json_match:
            result = json.loads(json_match.group())
            return {
                "primary": result.get("primary", "other"),
                "secondary": result.get("secondary", "其他"),
                "confidence": result.get("confidence", 0.5),
            }
        return self._keyword_fallback(user_message)

    def _keyword_fallback(self, user_message: str) -> dict:
        """关键词正则兜底：按顺序匹配，先匹配到的优先。"""
        for pattern, (primary, secondary) in KEYWORD_INTENT_MAP.items():
            if re.search(pattern, user_message, re.IGNORECASE):
                return {"primary": primary, "secondary": secondary, "confidence": 0.70}
        return {"primary": "other", "secondary": "其他", "confidence": 0.3}
