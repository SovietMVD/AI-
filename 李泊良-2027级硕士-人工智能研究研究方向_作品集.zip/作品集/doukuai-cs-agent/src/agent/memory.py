"""分层记忆系统：工作记忆 + 短期摘要 + 长期事实。"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional
from src.utils import logger


@dataclass
class Message:
    role: str        # user / ai / agent / system
    content: str
    timestamp: datetime = field(default_factory=datetime.now)


class Memory:
    """单会话的记忆管理。"""

    def __init__(self, max_working: int = 20):
        self.working: list[Message] = []       # 当前窗口内的消息
        self.short_term: list[dict] = []        # 压缩后的摘要
        self.long_term: dict[str, str] = {}     # 用户级持久事实（跨会话）
        self.max_working = max_working

    def add(self, role: str, content: str):
        self.working.append(Message(role=role, content=content))
        if len(self.working) > self.max_working:
            self._compact()

    def _compact(self):
        """将最旧的 5 条消息压缩为一条摘要，释放工作记忆空间。"""
        old = self.working[:5]
        summary_parts = []
        for m in old:
            snippet = m.content[:40].replace("\n", " ")
            summary_parts.append(f"[{m.role}]: {snippet}")
        self.short_term.append({
            "summary": "；".join(summary_parts),
            "time": datetime.now().isoformat(),
        })
        self.working = self.working[5:]
        logger.debug("记忆压缩", remaining=len(self.working), summaries=len(self.short_term))

    def remember(self, key: str) -> Optional[str]:
        """查询长期记忆（如用户偏好、历史问题）。"""
        return self.long_term.get(key)

    def memorize(self, key: str, value: str):
        """存入长期记忆。"""
        self.long_term[key] = value

    def get_context(self, max_summaries: int = 3) -> str:
        """拼装完整上下文，供注入 system prompt。"""
        parts = []
        if self.short_term:
            recent = self.short_term[-max_summaries:]
            parts.append("## 之前对话摘要\n" + "\n".join(s["summary"] for s in recent))
        if self.working:
            parts.append("## 当前对话\n" + "\n".join(
                f"[{m.role}]: {m.content}" for m in self.working
            ))
        return "\n\n".join(parts)

    def get_ai_user_dialog(self) -> str:
        """获取 AI 与用户的对话历史（用于生成摘要）。"""
        lines = []
        for m in self.working:
            if m.role in ("user", "ai"):
                lines.append(f"{'用户' if m.role == 'user' else 'AI'}: {m.content}")
        return "\n".join(lines)
