"""工具注册系统：Agent 可调用的工具函数。"""

from typing import Callable, Any

TOOL_REGISTRY: dict[str, Callable] = {}


def register_tool(name: str, description: str, parameters: dict):
    """装饰器：将异步函数注册为 Agent 可调用工具。"""
    def decorator(func):
        TOOL_REGISTRY[name] = func
        func._tool_def = {
            "name": name,
            "description": description,
            "input_schema": parameters,
        }
        return func
    return decorator


def get_tool_defs() -> list[dict]:
    """获取所有已注册工具的定义列表，用于 Anthropic API 调用。"""
    return [getattr(f, "_tool_def", {}) for f in TOOL_REGISTRY.values()]


# ──────────── 工具定义 ────────────

@register_tool(
    name="search_knowledge_base",
    description="检索客服知识库，查找与用户问题匹配的 FAQ 答案。短视频平台相关：账号、内容审核、变现、功能使用等。",
    parameters={
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "用户的原始问题或改写后的检索查询"},
            "category": {
                "type": "string",
                "enum": ["account", "content", "monetize", "social", "platform", "other"],
                "description": "意图分类，用于缩小检索范围"
            },
        },
        "required": ["query"],
    }
)
async def search_knowledge_base(query: str, category: str = "other") -> str:
    """检索知识库。实际调用由 Agent 注入的 retriever 完成。"""
    # 此函数由 Agent Core 在运行时注入实际检索逻辑
    # 这里仅提供签名和工具定义
    raise NotImplementedError("search_knowledge_base 的实际实现在 Agent.run() 中注入")


@register_tool(
    name="check_user_info",
    description="查询用户的平台信息：粉丝数、创作等级、近期违规记录、认证状态等。",
    parameters={
        "type": "object",
        "properties": {
            "user_id": {"type": "string", "description": "用户 ID"},
        },
        "required": ["user_id"],
    }
)
async def check_user_info(user_id: str) -> str:
    raise NotImplementedError("check_user_info 的实际实现在 Agent.run() 中注入")


@register_tool(
    name="create_ticket",
    description="创建工单，将复杂问题升级给人工团队处理。",
    parameters={
        "type": "object",
        "properties": {
            "title": {"type": "string", "description": "工单标题"},
            "category": {"type": "string", "description": "分类：account/content/monetize/social/platform/other"},
            "priority": {"type": "string", "enum": ["urgent", "high", "medium", "low"], "description": "优先级"},
            "summary": {"type": "string", "description": "问题摘要，100字以内"},
        },
        "required": ["title", "category", "priority", "summary"],
    }
)
async def create_ticket(title: str, category: str, priority: str, summary: str) -> str:
    raise NotImplementedError("create_ticket 的实际实现在 Agent.run() 中注入")


@register_tool(
    name="transfer_to_human",
    description="将当前会话转接给人工客服。当 AI 无法解决用户问题或用户明确要求时调用。",
    parameters={
        "type": "object",
        "properties": {
            "reason": {"type": "string", "description": "转接原因"},
            "summary": {"type": "string", "description": "AI 已了解的问题摘要，帮助人工客服快速上手"},
        },
        "required": ["reason", "summary"],
    }
)
async def transfer_to_human(reason: str, summary: str) -> str:
    raise NotImplementedError("transfer_to_human 的实际实现在 Agent.run() 中注入")
