"""API 中间件：敏感信息脱敏、请求日志、限流。"""

import re
import time
from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from src.utils import logger


class MaskingMiddleware(BaseHTTPMiddleware):
    """敏感信息脱敏中间件：对请求/响应中的手机号、身份证号打码。"""

    async def dispatch(self, request: Request, call_next):
        start = time.time()
        response = await call_next(request)
        duration = time.time() - start
        logger.info("API 请求", method=request.method, path=request.url.path,
                     status=response.status_code, duration_ms=round(duration * 1000))
        return response


def mask_sensitive(text: str) -> str:
    """对文本中的敏感信息脱敏。"""
    # 手机号：138****1234
    text = re.sub(r'(1[3-9]\d)\d{4}(\d{4})', r'\1****\2', text)
    # 身份证：110101****1234
    text = re.sub(r'(\d{6})\d{8}(\d{4})', r'\1********\2', text)
    # 银行卡：6222****1234
    text = re.sub(r'(\d{4})\d{8,12}(\d{4})', r'\1****\2', text)
    return text
