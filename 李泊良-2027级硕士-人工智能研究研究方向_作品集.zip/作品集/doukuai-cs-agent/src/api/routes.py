"""FastAPI 路由：用户聊天、客服工作台、知识库管理、数据看板。"""

import uuid
from typing import Optional
from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
import anthropic

from src.utils import settings, logger
from src.agent import CustomerServiceAgent
from src.rag import SentenceEmbedder, KnowledgeLoader, Retriever
from src.db import ConversationRepo, TicketRepo, KnowledgeRepo
from src.db.models import Conversation, Ticket, SessionStatus
from .middleware import MaskingMiddleware


# ── 请求模型 ──

class ChatRequest(BaseModel):
    message: str
    user_id: str = "anonymous"
    user_type: str = "normal"
    user_name: str = ""
    conversation_id: str = ""


class TicketCreateRequest(BaseModel):
    conversation_id: str
    title: str
    category: str
    priority: str = "medium"


class KBImportRequest(BaseModel):
    entries: list[dict]  # [{"question": "...", "answer": "...", "category": "..."}]


class FeedbackRequest(BaseModel):
    conversation_id: str
    score: int = 5  # 1-5
    helpful: bool = True


# ── 依赖注入 ──

engine = create_async_engine(settings.database_url, echo=False)
AsyncSessionLocal = async_sessionmaker(engine, expire_on_commit=False)

# 初始化 AI 组件
embedder = SentenceEmbedder()
knowledge_loader = KnowledgeLoader(embedder)
retriever = Retriever(embedder)
anthropic_client = anthropic.Anthropic(api_key=settings.anthropic_api_key)

# 全局 Agent（每个请求创建独立实例以隔离状态）
def get_agent() -> CustomerServiceAgent:
    return CustomerServiceAgent(anthropic_client, retriever, AsyncSessionLocal)


# ── Demo 模式自然对话引擎 ──

import random as _random

# 闲聊模式库
_CHITCHAT_PATTERNS = {
    "greeting": [
        "你好呀~ 👋 我是阿尔法视频助手，专门帮创作者解决视频制作和平台运营的问题。有什么可以帮你的？",
        "嗨！欢迎来找我聊天~ 不管是拍摄技巧还是账号问题，尽管问！😊",
        "哈喽~ 今天创作顺利吗？有什么想了解的随时问我！",
    ],
    "thanks": [
        "不客气~ 能帮到你就好！还有其他问题随时找我 😊",
        "客气啦~ 快去试试吧，有问题再来！💪",
        "嘿嘿，能帮到你我也开心~ 祝你创作顺利！🎬",
    ],
    "bye": [
        "拜拜~ 创作加油，有问题随时回来！👋",
        "好的，先去忙吧~ 需要帮助时我一直在！😊",
        "再见~ 期待你的下一个爆款视频！🎉",
    ],
    "praise_bot": [
        "哈哈谢谢夸奖~ 我会继续努力的！😆",
        "嘿嘿，被你夸得都不好意思了~ 有什么尽管问！",
        "谢谢！能帮到创作者就是我最大的动力~ 💪",
    ],
    "complain": [
        "理解你的心情！平台确实有些地方需要改进。如果有具体问题我可以帮你处理~",
        "嗯嗯，我懂你的感受。虽然有些事我改不了，但我可以帮你找到最快的解决路径！",
        "抱抱~ 遇到问题确实烦人。告诉我具体情况，我来想办法帮你！",
    ],
    "who_are_you": [
        "我是阿尔法视频助手~ 专门帮助短视频创作者的 AI 助手。拍摄技巧、账号问题、审核申诉、变现收益……只要跟短视频相关，都可以问我！🎬",
        "我是你的创作搭档阿尔法~ 不管是剪辑遇到坎、播放量上不去、还是不知道怎么变现，我都能帮你理一理！",
    ],
}

# 情绪安抚词库
_COMFORT_PHRASES = [
    "我理解你的心情，",
    "别着急，我来帮你看看。",
    "这个问题确实让人头疼，不过有办法的~",
    "嗯，我明白你的困扰。",
    "放心，我来帮你理一理。",
]

# KB 基础上的自然开场
_KB_OPENERS = [
    "好的，关于{}，这里有一些有用的信息：",
    "嗯，{}这个问题我帮你查了一下：",
    "了解~ 不少创作者也遇到过类似的问题，来看一下：",
    "收到！关于{}，整理了这些内容给你：",
]

# KB 基础上的自然结尾
_KB_CLOSERS = [
    "\n\n希望这些能帮到你~ 如果还有不清楚的地方，尽管追问！",
    "\n\n以上就是目前的信息啦。还有其他问题吗？",
    "\n\n需要我详细解释某一点的话，随时说~",
    "\n\n试试看这些方法，不行的话我帮你转人工客服~",
    "\n\n觉得有用的话就太好了！还有其他想了解的吗？",
]

# 无匹配时的回复
_NO_MATCH_RESPONSES = [
    "抱歉，我目前的知识库里还没有关于这个问题的详细资料 😅\n\n建议你试试：\n1. 换一种方式描述你的问题\n2. 输入「转人工」联系在线客服\n3. 告诉我更多细节，我帮你再找找",
    "嗯...这个问题有点特殊，我的知识库里暂时没有找到匹配的内容。\n\n要不这样：\n• 试试用更简短的关键词提问\n• 或者我帮你转人工客服，让专业同事来解答",
]


def _get_chitchat(msg: str) -> str | None:
    """识别闲聊并返回自然回复，非闲聊返回 None。"""
    msg_lower = msg.strip().lower()

    # 问候
    if len(msg) <= 5 and any(w in msg_lower for w in ["你好", "hi", "hello", "嗨", "哈喽", "在吗", "在不在", "早上好", "下午好", "晚上好", "hey"]):
        return _random.choice(_CHITCHAT_PATTERNS["greeting"])

    # 感谢/夸奖
    if any(w in msg for w in ["谢谢", "感谢", "多谢", "辛苦了", "太棒了", "很好用", "你真棒", "你真厉害", "不错", "有用"]):
        return _random.choice(_CHITCHAT_PATTERNS["thanks"])

    # 告别
    if len(msg) <= 6 and any(w in msg for w in ["再见", "拜拜", "bye", "回头见", "走了", "886"]):
        return _random.choice(_CHITCHAT_PATTERNS["bye"])

    # 夸奖 Bot
    if any(w in msg for w in ["你真聪明", "你好厉害", "你好棒", "你真好", "你好可爱", "机器人不错"]):
        return _random.choice(_CHITCHAT_PATTERNS["praise_bot"])

    # 吐槽/抱怨（无实质内容）
    if len(msg) <= 15 and any(w in msg for w in ["好烦", "垃圾", "太难了", "无语", "崩溃", "烦死了", "唉", "哎", "什么鬼", "坑爹"]):
        return _random.choice(_CHITCHAT_PATTERNS["complain"])

    # 你是谁
    if any(w in msg for w in ["你是谁", "你叫什么", "你是什么", "介绍一下", "你是干嘛的"]):
        return _random.choice(_CHITCHAT_PATTERNS["who_are_you"])

    return None


def _build_natural_response(msg: str, intent: dict, kb_text: str, kb_count: int) -> str:
    """构建自然对话回复，融合 KB 内容。"""
    secondary = intent.get("secondary", "这个问题")
    primary = intent.get("primary", "other")

    parts = []

    # Step 1: 情绪安抚（检测负面情绪词）
    negative_words = ["急", "气死", "崩溃", "无语", "受不了", "一直", "老是", "总是", "怎么办啊", "救命"]
    if any(w in msg for w in negative_words):
        parts.append(_random.choice(_COMFORT_PHRASES))

    # Step 2: 打开话题
    parts.append(_random.choice(_KB_OPENERS).format(secondary))

    # Step 3: 知识库内容（去掉 Q:/A: 标记，用自然格式）
    if kb_text:
        cleaned = kb_text.replace("Q: ", "").replace("A: ", "").replace("📌 ", "").strip()
        # 如果 KB 内容已有编号则保持，否则保持原样
        parts.append(cleaned)
    else:
        return _random.choice(_NO_MATCH_RESPONSES)

    # Step 4: 结尾引导
    parts.append(_random.choice(_KB_CLOSERS))

    return "\n\n".join(parts)


# ── 应用工厂 ──

def create_app() -> FastAPI:
    app = FastAPI(
        title="阿尔法 AI 智能客服",
        description="短视频平台 AI 客服系统 API",
        version="1.0.0",
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(MaskingMiddleware)

    # ─── 用户端 API ───

    @app.post("/api/v1/chat/send")
    async def chat_send(req: ChatRequest, agent: CustomerServiceAgent = Depends(get_agent)):
        """发送消息，流式返回 AI 回复。"""
        async def event_stream():
            async for event in agent.run(
                user_input=req.message,
                user_id=req.user_id,
                user_type=req.user_type,
                user_name=req.user_name,
                conversation_id=req.conversation_id,
            ):
                if event["type"] == "text":
                    yield f"data: {event['content']}\n\n"
                elif event["type"] == "tool_call":
                    yield f"event: tool\ndata: {event['name']}\n\n"
                elif event["type"] == "done":
                    yield f"event: done\ndata: {event.get('action', 'resolved')}\n\n"
                    yield f"data: [DONE]\n\n"

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={"X-Conversation-ID": req.conversation_id},
        )

    @app.post("/api/v1/chat/demo")
    async def chat_demo(req: ChatRequest):
        """Demo 模式：不依赖 LLM API Key，自然对话引擎 + 知识库检索。"""
        from src.agent.intent import IntentClassifier
        import re, random

        classifier = IntentClassifier(None, "")
        intent = classifier._keyword_fallback(req.message)
        msg = req.message.strip()

        # ── 转人工检测 ──
        transfer_keywords = ["转人工", "人工客服", "人工服务", "找人工", "联系人工", "客服电话"]
        is_transfer = any(kw in msg for kw in transfer_keywords)

        if is_transfer:
            async def transfer_stream():
                queue_num = random.randint(2, 6)
                wait_min = random.randint(2, 5)
                ticket_id = f"TK-{random.randint(10000, 99999)}"
                lines = [
                    f"收到啦~ 正在为你转接人工客服 🎧",
                    f"",
                    f"📋 已整理好你的会话摘要，客服同事会第一时间了解你的问题",
                    f"📍 当前排队：前方 {queue_num} 人",
                    f"⏱ 预计等待：约 {wait_min} 分钟",
                    f"📌 工单编号：{ticket_id}",
                    f"",
                    f"等待期间你可以继续描述问题，我会同步给人工客服~",
                ]
                full = "\n".join(lines)
                for i in range(0, len(full), 3):
                    yield f"data: {full[i:i+3]}\n\n"
                    import asyncio
                    await asyncio.sleep(0.02)
                yield f"event: done\ndata: transferred\n\n"
                yield f"data: [DONE]\n\n"

            return StreamingResponse(
                transfer_stream(),
                media_type="text/event-stream",
                headers={"X-Conversation-ID": req.conversation_id},
            )

        # ── 闲聊处理器 ──
        chitchat_response = _get_chitchat(msg)
        if chitchat_response:
            async def chitchat_stream():
                for i in range(0, len(chitchat_response), 3):
                    yield f"data: {chitchat_response[i:i+3]}\n\n"
                    import asyncio
                    await asyncio.sleep(0.02)
                yield f"event: done\ndata: demo_resolved\n\n"
                yield f"data: [DONE]\n\n"

            return StreamingResponse(
                chitchat_stream(),
                media_type="text/event-stream",
            )

        # 知识库检索
        docs = await retriever.retrieve(req.message, intent["primary"])
        kb_text = "\n\n".join(docs[:3]) if docs else ""
        kb_count = len(docs)

        # ── 构建自然回复 ──
        response = _build_natural_response(msg, intent, kb_text, kb_count)

        async def event_stream():
            for i in range(0, len(response), 3):
                yield f"data: {response[i:i+3]}\n\n"
                import asyncio
                await asyncio.sleep(0.02)
            yield f"event: done\ndata: demo_resolved\n\n"
            yield f"data: [DONE]\n\n"

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
        )

    @app.post("/api/v1/chat/transfer")
    async def chat_transfer(req: ChatRequest):
        """用户请求转人工。"""
        async with AsyncSessionLocal() as db:
            repo = ConversationRepo(db)
            conv = await repo.get(req.conversation_id)
            if conv:
                await repo.update_status(str(conv.id), SessionStatus.HUMAN_PROCESSING)
                await repo.set_summary(str(conv.id), "用户主动请求转人工")
        return {"status": "transferred", "message": "已转接人工客服，请稍候"}

    @app.get("/api/v1/chat/history")
    async def chat_history(conversation_id: str = Query(...)):
        """查询历史对话。"""
        async with AsyncSessionLocal() as db:
            repo = ConversationRepo(db)
            messages = await repo.get_messages(conversation_id, limit=100)
            return {
                "messages": [
                    {"role": m.sender_type, "content": m.content,
                     "time": m.created_at.isoformat(), "intent": m.intent}
                    for m in messages
                ]
            }

    @app.post("/api/v1/chat/feedback")
    async def chat_feedback(req: FeedbackRequest):
        """用户满意度评价。"""
        async with AsyncSessionLocal() as db:
            repo = ConversationRepo(db)
            conv = await repo.get(req.conversation_id)
            if conv:
                conv.satisfaction_score = req.score
                await db.commit()
        return {"status": "ok"}

    # ─── 客服工作台 API ───

    @app.get("/api/v1/agent/sessions")
    async def agent_sessions(status: str = "pending", limit: int = 20):
        """获取待处理/进行中的会话列表。"""
        # 简化实现，生产环境需关联 agent_id
        return {"sessions": [], "total": 0}

    @app.post("/api/v1/agent/sessions/{session_id}/claim")
    async def agent_claim_session(session_id: str, agent_id: str = Query(...)):
        """客服认领会话。"""
        async with AsyncSessionLocal() as db:
            repo = ConversationRepo(db)
            await repo.update_status(session_id, SessionStatus.HUMAN_PROCESSING)
        return {"status": "claimed"}

    # ─── 知识库 API ───

    @app.get("/api/v1/kb/search")
    async def kb_search(query: str = Query(...), category: str = Query("other"), top_k: int = Query(5)):
        """知识库检索。"""
        docs = await retriever.retrieve(query, category, top_k)
        return {"results": docs, "query": query}

    @app.post("/api/v1/kb/entries")
    async def kb_import(req: KBImportRequest):
        """批量导入知识条目。"""
        # 简化：写入临时 JSON 然后 reload
        import json, tempfile, os
        with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False, encoding="utf-8") as f:
            entries_with_id = []
            for i, entry in enumerate(req.entries):
                entries_with_id.append({
                    "id": f"kb_{uuid.uuid4().hex[:8]}",
                    "question": entry.get("question", ""),
                    "answer": entry.get("answer", ""),
                    "category": entry.get("category", "other"),
                    "similar_questions": entry.get("similar_questions", []),
                })
            json.dump(entries_with_id, f, ensure_ascii=False)
            tmp_path = f.name
        count = knowledge_loader.load_from_json(tmp_path)
        os.unlink(tmp_path)
        return {"status": "ok", "imported": count}

    # ─── 健康检查 ───

    @app.get("/health")
    async def health_check():
        kb_count = knowledge_loader.get_count()
        return {
            "status": "healthy",
            "kb_entries": kb_count,
            "model": settings.anthropic_model,
        }

    return app
