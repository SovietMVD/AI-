"""数据模型：对应 PRD 中的核心实体。"""

import uuid
from datetime import datetime
from sqlalchemy import String, Integer, Float, Text, DateTime, Boolean, ForeignKey, Enum as SAEnum
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
import enum


class Base(DeclarativeBase):
    pass


class UserType(str, enum.Enum):
    NORMAL = "normal"       # 普通用户
    CREATOR = "creator"     # 创作者
    ADVERTISER = "advertiser"  # 广告主


class SessionStatus(str, enum.Enum):
    AI_PROCESSING = "ai_processing"
    HUMAN_PROCESSING = "human_processing"
    RESOLVED = "resolved"
    EXPIRED = "expired"


class TicketStatus(str, enum.Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    WAITING_CONFIRM = "waiting_confirm"
    RESOLVED = "resolved"


class TicketPriority(str, enum.Enum):
    URGENT = "urgent"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class Conversation(Base):
    """会话：一次完整的用户咨询。"""
    __tablename__ = "conversations"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id: Mapped[str] = mapped_column(String(64), index=True)
    user_type: Mapped[UserType] = mapped_column(SAEnum(UserType), default=UserType.NORMAL)
    user_name: Mapped[str] = mapped_column(String(128), default="")
    status: Mapped[SessionStatus] = mapped_column(SAEnum(SessionStatus), default=SessionStatus.AI_PROCESSING)
    ai_summary: Mapped[str] = mapped_column(Text, default="")  # AI 对话摘要
    satisfaction_score: Mapped[int] = mapped_column(Integer, nullable=True)  # 1-5 评分
    intent_category: Mapped[str] = mapped_column(String(64), default="")  # 识别到的意图分类
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    messages: Mapped[list["Message"]] = relationship(back_populates="conversation", order_by="Message.created_at")


class Message(Base):
    """消息：会话中的单条消息。"""
    __tablename__ = "messages"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    conversation_id: Mapped[str] = mapped_column(String(36), ForeignKey("conversations.id"), index=True)
    sender_type: Mapped[str] = mapped_column(String(16))  # user / ai / agent / system
    content: Mapped[str] = mapped_column(Text)
    msg_type: Mapped[str] = mapped_column(String(32), default="text")  # text / image / card / system
    intent: Mapped[str] = mapped_column(String(64), default="")  # AI 消息的意图分类
    confidence: Mapped[float] = mapped_column(Float, default=0.0)  # AI 意图置信度
    kb_entry_id: Mapped[str] = mapped_column(String(36), default="")  # 命中的知识条目
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    conversation: Mapped["Conversation"] = relationship(back_populates="messages")


class Ticket(Base):
    """工单：复杂问题的升级处理。"""
    __tablename__ = "tickets"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    conversation_id: Mapped[str] = mapped_column(String(36), index=True)
    title: Mapped[str] = mapped_column(String(256))
    category: Mapped[str] = mapped_column(String(64))  # 账号 / 内容 / 变现 / 其他
    priority: Mapped[TicketPriority] = mapped_column(SAEnum(TicketPriority), default=TicketPriority.MEDIUM)
    status: Mapped[TicketStatus] = mapped_column(SAEnum(TicketStatus), default=TicketStatus.PENDING)
    assignee: Mapped[str] = mapped_column(String(64), default="")
    resolution: Mapped[str] = mapped_column(Text, default="")
    sla_deadline: Mapped[datetime] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class KnowledgeEntry(Base):
    """知识条目：FAQ 问答对。"""
    __tablename__ = "knowledge_entries"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    question: Mapped[str] = mapped_column(String(512))  # 标准问法
    similar_questions: Mapped[str] = mapped_column(Text, default="[]")  # JSON 数组：相似问法
    answer: Mapped[str] = mapped_column(Text)
    category: Mapped[str] = mapped_column(String(64), index=True)  # 意图分类
    intent_id: Mapped[str] = mapped_column(String(64), default="")
    status: Mapped[str] = mapped_column(String(16), default="published")  # published / draft / offline
    version: Mapped[int] = mapped_column(Integer, default=1)
    hit_count: Mapped[int] = mapped_column(Integer, default=0)  # 命中次数
    helpful_count: Mapped[int] = mapped_column(Integer, default=0)
    not_helpful_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
