"""数据访问层：封装 SQLAlchemy 异步操作。"""

import json
from datetime import datetime
from typing import Optional
from sqlalchemy import select, update, func
from sqlalchemy.ext.asyncio import AsyncSession
from .models import Conversation, Message, Ticket, KnowledgeEntry, SessionStatus


class ConversationRepo:
    """会话仓库。"""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, conv: Conversation) -> Conversation:
        self.session.add(conv)
        await self.session.commit()
        return conv

    async def get(self, conv_id: str) -> Optional[Conversation]:
        return await self.session.get(Conversation, conv_id)

    async def update_status(self, conv_id: str, status: SessionStatus):
        await self.session.execute(
            update(Conversation).where(Conversation.id == conv_id).values(status=status)
        )
        await self.session.commit()

    async def add_message(self, msg: Message):
        self.session.add(msg)
        await self.session.commit()

    async def get_messages(self, conv_id: str, limit: int = 50) -> list[Message]:
        result = await self.session.execute(
            select(Message)
            .where(Message.conversation_id == conv_id)
            .order_by(Message.created_at.asc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def set_summary(self, conv_id: str, summary: str):
        await self.session.execute(
            update(Conversation).where(Conversation.id == conv_id).values(ai_summary=summary)
        )
        await self.session.commit()

    async def get_active_by_user(self, user_id: str) -> Optional[Conversation]:
        """获取用户当前活跃会话（AI 或人工处理中的）。"""
        result = await self.session.execute(
            select(Conversation)
            .where(
                Conversation.user_id == user_id,
                Conversation.status.in_([SessionStatus.AI_PROCESSING, SessionStatus.HUMAN_PROCESSING])
            )
            .order_by(Conversation.created_at.desc())
            .limit(1)
        )
        return result.scalar_one_or_none()


class TicketRepo:
    """工单仓库。"""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def create(self, ticket: Ticket) -> Ticket:
        self.session.add(ticket)
        await self.session.commit()
        return ticket

    async def get(self, ticket_id: str) -> Optional[Ticket]:
        return await self.session.get(Ticket, ticket_id)

    async def list_pending(self, limit: int = 20) -> list[Ticket]:
        result = await self.session.execute(
            select(Ticket).where(Ticket.status == "pending").order_by(Ticket.created_at.asc()).limit(limit)
        )
        return list(result.scalars().all())

    async def assign(self, ticket_id: str, agent_id: str):
        await self.session.execute(
            update(Ticket).where(Ticket.id == ticket_id).values(assignee=agent_id, status="processing")
        )
        await self.session.commit()

    async def resolve(self, ticket_id: str, resolution: str):
        await self.session.execute(
            update(Ticket).where(Ticket.id == ticket_id).values(
                status="resolved", resolution=resolution, updated_at=datetime.utcnow()
            )
        )
        await self.session.commit()


class KnowledgeRepo:
    """知识库仓库。"""

    def __init__(self, session: AsyncSession):
        self.session = session

    async def search_by_category(self, category: str, limit: int = 10) -> list[KnowledgeEntry]:
        result = await self.session.execute(
            select(KnowledgeEntry)
            .where(KnowledgeEntry.category == category, KnowledgeEntry.status == "published")
            .order_by(KnowledgeEntry.hit_count.desc())
            .limit(limit)
        )
        return list(result.scalars().all())

    async def get(self, kb_id: str) -> Optional[KnowledgeEntry]:
        return await self.session.get(KnowledgeEntry, kb_id)

    async def increment_hit(self, kb_id: str, helpful: bool = True):
        entry = await self.get(kb_id)
        if entry:
            entry.hit_count += 1
            if helpful:
                entry.helpful_count += 1
            else:
                entry.not_helpful_count += 1
            await self.session.commit()

    async def list_all_published(self) -> list[KnowledgeEntry]:
        result = await self.session.execute(
            select(KnowledgeEntry).where(KnowledgeEntry.status == "published")
        )
        return list(result.scalars().all())

    async def import_batch(self, entries: list[KnowledgeEntry]):
        self.session.add_all(entries)
        await self.session.commit()
