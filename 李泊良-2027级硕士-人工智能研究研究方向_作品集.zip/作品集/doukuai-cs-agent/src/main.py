"""阿尔法 AI 智能客服 — 服务入口。

启动方式：
    python -m src.main
    uvicorn src.main:app --host 0.0.0.0 --port 8000 --reload
"""

import uvicorn
from src.api.routes import create_app
from src.utils import settings, logger

app = create_app()


def main():
    logger.info("启动阿尔法 AI 智能客服服务", host=settings.host, port=settings.port)
    uvicorn.run(
        "src.main:app",
        host=settings.host,
        port=settings.port,
        reload=settings.debug,
        log_level=settings.log_level.lower(),
    )


if __name__ == "__main__":
    main()
