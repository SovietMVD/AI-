"""向量化服务：基于 sentence-transformers 的文本嵌入。"""

from sentence_transformers import SentenceTransformer
from src.utils import logger


class SentenceEmbedder:
    """sentence-transformers 封装，支持批量向量化。"""

    def __init__(self, model_name: str = "BAAI/bge-small-zh-v1.5"):
        # 中文优化模型，384 维，轻量快速
        self.model = SentenceTransformer(model_name)
        self.dim = self.model.get_sentence_embedding_dimension()
        logger.info("向量模型加载完成", model=model_name, dim=self.dim)

    def embed(self, text: str) -> list[float]:
        """单条文本向量化。"""
        return self.model.encode(text, normalize_embeddings=True).tolist()

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """批量向量化。"""
        embeddings = self.model.encode(texts, normalize_embeddings=True, show_progress_bar=False)
        return embeddings.tolist()
