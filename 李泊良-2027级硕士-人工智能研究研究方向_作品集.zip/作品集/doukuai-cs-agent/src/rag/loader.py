"""知识库加载器：从 JSON/CSV 文件加载 FAQ，向量化后存入 Chroma。"""

import json
import os
from typing import Optional
import chromadb
from src.utils import settings, logger
from .embeddings import SentenceEmbedder


class KnowledgeLoader:
    """知识库初始化与增量更新。"""

    def __init__(self, embedder: SentenceEmbedder):
        self.embedder = embedder
        self.client = chromadb.PersistentClient(path=settings.chroma_persist_dir)
        self.collection = self.client.get_or_create_collection(
            name="cs_knowledge_base",
            metadata={"hnsw:space": "cosine"},
        )

    def load_from_json(self, file_path: str) -> int:
        """从 JSON 文件加载 FAQ 数据。
        JSON 格式：[{"id": "...", "question": "...", "answer": "...", "category": "..."}, ...]
        返回加载条数。
        """
        if not os.path.exists(file_path):
            logger.warning("知识库文件不存在", path=file_path)
            return 0

        with open(file_path, "r", encoding="utf-8") as f:
            faqs = json.load(f)

        ids = []
        documents = []
        metadatas = []
        embeddings = []

        for faq in faqs:
            doc_id = faq.get("id", "")
            question = faq.get("question", "")
            answer = faq.get("answer", "")
            category = faq.get("category", "other")
            similar = faq.get("similar_questions", [])

            # 主问题向量化
            ids.append(doc_id)
            doc_text = f"Q: {question}\nA: {answer}"
            documents.append(doc_text)
            metadatas.append({"category": category, "question": question, "type": "main"})
            embeddings.append(self.embedder.embed(question))

            # 相似问法也向量化，指向同一答案
            for i, sq in enumerate(similar):
                ids.append(f"{doc_id}_sim_{i}")
                documents.append(doc_text)
                metadatas.append({"category": category, "question": sq, "type": "similar"})
                embeddings.append(self.embedder.embed(sq))

        if ids:
            self.collection.add(
                ids=ids,
                documents=documents,
                metadatas=metadatas,
                embeddings=embeddings,
            )

        logger.info("知识库加载完成", count=len(faqs), total_vectors=len(ids))
        return len(faqs)

    def get_count(self) -> int:
        return self.collection.count()
