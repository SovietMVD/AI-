"""知识检索器：向量检索 + 类别过滤 + 重排序。"""

from typing import List, Optional
import chromadb
from src.utils import settings, logger
from .embeddings import SentenceEmbedder


class Retriever:
    """基于 Chroma 的知识库检索。支持按意图类别过滤。"""

    def __init__(self, embedder: SentenceEmbedder):
        self.embedder = embedder
        self.client = chromadb.PersistentClient(path=settings.chroma_persist_dir)
        self.collection = self.client.get_or_create_collection(
            name="cs_knowledge_base",
            metadata={"hnsw:space": "cosine"},
        )
        self.score_threshold = 0.65  # 相似度阈值

    async def retrieve(self, query: str, category: Optional[str] = None, top_k: int = 5) -> List[str]:
        """检索相关知识条目。先按类别过滤，无结果时放宽到全库检索。"""
        query_vec = self.embedder.embed(query)

        # 带类别过滤的检索
        where_filter = None
        if category and category != "other":
            where_filter = {"category": category}

        try:
            results = self.collection.query(
                query_embeddings=[query_vec],
                n_results=top_k * 2,  # 多取一些用于去重
                where=where_filter,
                include=["documents", "metadatas", "distances"],
            )
        except Exception:
            # 类别过滤无结果时，回退到全库检索
            results = self.collection.query(
                query_embeddings=[query_vec],
                n_results=top_k,
                include=["documents", "metadatas", "distances"],
            )

        # 去重 + 按分数过滤
        seen = set()
        docs = []
        for i, doc_id in enumerate(results["ids"][0]):
            doc = results["documents"][0][i]
            score = 1 - results["distances"][0][i]  # cosine distance → similarity
            doc_hash = doc[:50]  # 去重 key

            if doc_hash not in seen and score >= self.score_threshold:
                seen.add(doc_hash)
                docs.append(doc)
                if len(docs) >= top_k:
                    break

        logger.debug("知识检索", query=query[:30], category=category, hits=len(docs))
        return docs

    def format_context(self, docs: List[str]) -> str:
        """将检索结果格式化为 LLM 可读的上下文块。"""
        if not docs:
            return ""
        return "## 知识库匹配结果\n\n" + "\n\n---\n\n".join(
            f"[参考 {i+1}]\n{doc}" for i, doc in enumerate(docs)
        )
