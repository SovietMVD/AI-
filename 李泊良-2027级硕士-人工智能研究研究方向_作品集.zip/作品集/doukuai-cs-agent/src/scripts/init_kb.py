"""阿尔法 AI 智能客服 — 知识库初始化脚本。
首次运行或更新知识库后执行：
    python -m src.scripts.init_kb
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from src.rag import SentenceEmbedder, KnowledgeLoader


def init_knowledge_base():
    embedder = SentenceEmbedder()
    loader = KnowledgeLoader(embedder)

    faq_path = os.path.join(os.path.dirname(__file__), "..", "..", "knowledge_base", "sample_faqs.json")
    count = loader.load_from_json(faq_path)
    print(f"知识库初始化完成，加载 {count} 条 FAQ，共 {loader.get_count()} 个向量")


if __name__ == "__main__":
    init_knowledge_base()
