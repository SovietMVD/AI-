"""配置管理：从环境变量加载，提供类型安全的 settings 单例。"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Anthropic
    anthropic_api_key: str = ""
    anthropic_model: str = "claude-sonnet-4-6"

    # 服务
    host: str = "0.0.0.0"
    port: int = 8000
    debug: bool = False

    # 数据库
    database_url: str = "sqlite+aiosqlite:///./data/cs_agent.db"

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # 向量数据库
    chroma_persist_dir: str = "./data/chroma"
    vector_db_type: str = "chroma"

    # JWT
    jwt_secret: str = "dev-secret-change-me"
    jwt_expire_minutes: int = 1440

    # 加密
    encryption_key: str = "dev-key-32-bytes-change-in-prod!!"

    # 日志
    log_level: str = "INFO"
    log_file: str = "./data/logs/app.log"

    # 客服业务配置
    max_agent_iterations: int = 8  # Agent 最大推理轮次
    ai_confidence_threshold: float = 0.85  # 高置信度阈值
    ai_fallback_threshold: float = 0.60  # 转人工兜底阈值
    session_ttl_seconds: int = 1800  # 会话超时 30 分钟

    model_config = {"env_file": ".env", "env_file_encoding": "utf-8"}


settings = Settings()
