"""测试：Agent 核心循环（Mock 模式，无需 API Key）。"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch


class TestIntentClassifier:
    def test_keyword_fallback_account(self):
        from src.agent.intent import IntentClassifier
        classifier = IntentClassifier(None, "claude-sonnet-4-6")
        result = classifier._keyword_fallback("我账号登不上了")
        assert result["primary"] == "account"

    def test_keyword_fallback_content(self):
        from src.agent.intent import IntentClassifier
        classifier = IntentClassifier(None, "claude-sonnet-4-6")
        result = classifier._keyword_fallback("视频审核怎么申诉")
        assert result["primary"] == "content"

    def test_keyword_fallback_monetize(self):
        from src.agent.intent import IntentClassifier
        classifier = IntentClassifier(None, "claude-sonnet-4-6")
        result = classifier._keyword_fallback("收益什么时候到账")
        assert result["primary"] == "monetize"

    def test_keyword_fallback_unknown(self):
        from src.agent.intent import IntentClassifier
        classifier = IntentClassifier(None, "claude-sonnet-4-6")
        result = classifier._keyword_fallback("今天天气不错")
        assert result["primary"] == "other"
        assert result["confidence"] == 0.3


class TestMemory:
    def test_add_and_compact(self):
        from src.agent.memory import Memory
        memory = Memory(max_working=5)
        for i in range(8):
            memory.add("user", f"消息{i}")
        assert len(memory.working) == 3
        assert len(memory.short_term) == 1

    def test_context_building(self):
        from src.agent.memory import Memory
        memory = Memory(max_working=10)
        memory.add("user", "测试问题")
        memory.add("ai", "测试回答")
        ctx = memory.get_context()
        assert "测试问题" in ctx
        assert "测试回答" in ctx


class TestMasking:
    def test_mask_phone(self):
        from src.api.middleware import mask_sensitive
        result = mask_sensitive("我的手机是13812345678")
        assert "138****5678" in result
        assert "1381234" not in result

    def test_mask_idcard(self):
        from src.api.middleware import mask_sensitive
        result = mask_sensitive("身份证110101199001011234")
        assert "110101********1234" in result

    def test_no_mask_needed(self):
        from src.api.middleware import mask_sensitive
        text = "为什么视频限流了？"
        assert mask_sensitive(text) == text
